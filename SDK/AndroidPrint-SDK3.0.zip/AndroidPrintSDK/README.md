# AndroidPrintSDK
Android 手机通过 蓝牙 WIFI USB 与打印机通讯的示例代码
支持文字打印, 条码, 二维码 标签, 图片等打印
使用ESC/POS标准指令与热敏打印机通讯
